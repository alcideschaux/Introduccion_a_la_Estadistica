abline(h = mean(autos$precio[autos$tipo=="grande"]), col = "red", lwd = 3)
