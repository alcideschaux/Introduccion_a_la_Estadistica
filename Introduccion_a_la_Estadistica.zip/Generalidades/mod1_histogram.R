# Histogram
hist(autos$mpgCiudad, xlab = "Millas Por Galón (MPG)", ylab = "Frecuencia", main = "")
