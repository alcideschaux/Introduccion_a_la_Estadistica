# Box plot
boxplot(precio ~ tipo, data = autos, xlab = "Tipo", ylab = "Precio")
