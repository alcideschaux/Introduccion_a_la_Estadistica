# Stem and leaf plot
cat("\n")
stem(autos$mpgCiudad)
