# Scatter plot
plot(precio ~ peso, data = autos, xlab = "Peso (Libras)", ylab = "Precio ($1000s)")
