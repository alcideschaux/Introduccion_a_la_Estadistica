abline(v=c(min(autos$precio), max(autos$precio)), col="red", lwd=3)
